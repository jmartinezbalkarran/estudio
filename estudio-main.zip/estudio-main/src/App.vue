<script setup>
import Estructura from './components/Estructura.vue'
</script>

<template>

  <Estructura/>
</template>

<style scoped>

</style>
