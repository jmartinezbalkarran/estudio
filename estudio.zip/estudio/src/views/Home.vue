<template>
  <div class="home">
    <h1>Esta es la página de inicio</h1>
    <p>
      <router-link to="/about">Ir a About</router-link>
    </p>
  </div>
</template>

<script>
export default {
  name: 'HomeView'
}
</script>