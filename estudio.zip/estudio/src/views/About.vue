<template>
  <div class="about">
    <h1>Esta es la página About</h1>
    <p>
      <router-link to="/">Volver al Home</router-link>
    </p>
  </div>
</template>

<script>
export default {
  name: 'AboutView'
}
</script>